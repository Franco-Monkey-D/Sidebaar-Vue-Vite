<template>
    <main class="home-page">
        <h1>Home</h1>
        <p>This is  the home</p>
        
        
        <div class="inicio">
            <h1>Bienvenido a mi sitio web</h1>
            <p>En este sitio encontrarás información sobre nuestros productos y servicios.</p>
            <h2>Productos destacados</h2>
            <ul>
                <li v-for="producto in productos" :key="producto.id">
                    <h3>{{ producto.nombre }}</h3>
                    <p>{{ producto.descripcion }}</p>
                </li>
            </ul>
            <h2>Servicios</h2>
            <ul>
                <li v-for="servicio in servicios" :key="servicio.id">{{ servicio.nombre }}</li>
            </ul>
        </div>
        
    </main>
      
      
    </template>

    <script>
    export default {
      data() {
        return {
          productos: [
            { id: 1, nombre: 'Celulares', descripcion: 'Faciles y comodos de usar' },
            { id: 2, nombre: 'Computadora', descripcion: 'La informacion en un solo click' },
            { id: 3, nombre: 'Teclados', descripcion: 'Escribir siempre fue divertido?' }
          ],
          servicios: [
            { id: 1, nombre: 'Limpieza de equipo informatico' },
            { id: 2, nombre: 'Instalacion de redes' },
            { id: 3, nombre: 'Creacion de programas' }
          ]
        };
      }
    };
    </script>

  
  <style scoped>
  .inicio {
    max-width: 800px;
    margin: auto;
  }
  
  h1 {
    font-size: 48px;
  }
  
  h2 {
    font-size: 36px;
  }
  
  ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
  }
  
  li {
    margin-bottom: 20px;
  }
  
  h3 {
    font-size: 24px;
  }
  </style>
  