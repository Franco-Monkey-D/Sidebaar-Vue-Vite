<template>
    <main class="explore-page">
        <h1>Explore</h1>
        <p>Tu Trabajas aqui</p>
        <iframe class="mapa" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d4613.661313389374!2d-88.166044775313!3d13.498035236169025!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8f7ad57c83cbe6e9%3A0xc9ed502797ac1412!2sITCA-FEPADE%20San%20Miguel!5e0!3m2!1ses-419!2ssv!4v1696117189260!5m2!1ses-419!2ssv" width="800" height="600" style="border:0;"  loading="lazy" referrerpolicy="no-referrer-when-downgrade">

        </iframe>
    </main>
</template>

<style lang="scss" scoped>
/* Estilos para el mapa */
.explore-page {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
  }
  
  .mapa {
    width: 100%;
    height: 100%;
  }
</style>