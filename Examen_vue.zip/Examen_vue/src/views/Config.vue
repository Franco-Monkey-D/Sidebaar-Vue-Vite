<template>
    <main class="config-page">
        <h1>Configuracion</h1>
        <p>This is  the config page</p>

<br><br>
        <div>
            <table class="tabla-usuarios">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Correo electrónico</th>
                  <th>Teléfono</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="usuario in usuarios" :key="usuario.id">
                  <td>{{ usuario.nombre }}</td>
                  <td>{{ usuario.correo }}</td>
                  <td>{{ usuario.telefono }}</td>
                </tr>
              </tbody>
            </table>
          </div>

    </main>
</template>

<script>
export default {
  data() {
    return {
      usuarios: [
        {
          id: 1,
          nombre: 'Juan Pérez',
          correo: 'juan.perez@example.com',
          telefono: '7555-1234'
        },
        {
          id: 2,
          nombre: 'María Gómez',
          correo: 'maria.gomez@example.com',
          telefono: '6555-5678'
        },
        {
          id: 3,
          nombre: 'Pedro Rodríguez',
          correo: 'pedro.rodriguez@example.com',
          telefono: '7845-9012'
        }
      ]
    };
  }
};
</script>

<style>
.tabla-usuarios {
  border-collapse: collapse;
  width: 100%;
}

.tabla-usuarios th, .tabla-usuarios td {
  border: 1px solid #ddd;
  padding: 8px;
}

.tabla-usuarios th {
  background-color: #f2f2f2;
  color: #333;
  font-weight: bold;
}
</style>