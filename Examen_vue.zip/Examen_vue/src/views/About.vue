<template>
    <main class="about-page">
        <h1>About</h1>
        <p>This is  the about page</p>
<br><br>
        <div>
            <h1>Acerca de nosotros</h1>
            <p>Somos una empresa dedicada a ofrecer soluciones tecnológicas innovadoras.</p>
            <h2>Nuestro equipo</h2>
            <ul>
              <li v-for="miembro in equipo" :key="miembro.id">
                <h3>{{ miembro.nombre }}</h3>
                <p>{{ miembro.descripcion }}</p>
              </li>
            </ul>
          </div>

    </main>
</template>

<script>
export default {
  data() {
    return {
      equipo: [
        {
          id: 1,
          nombre: 'Juan Pérez',
          descripcion: 'Desarrollador web'
        },
        {
          id: 2,
          nombre: 'María Gómez',
          descripcion: 'Diseñadora gráfica'
        },
        {
          id: 3,
          nombre: 'Pedro Rodríguez',
          descripcion: 'Gerente de proyectos'
        }
      ]
    };
  }
}
</script>

<style>
h1 {
  font-size: 36px;
  font-weight: bold;
  margin-bottom: 20px;
}

p {
  font-size: 18px;
  line-height: 1.5;
  margin-bottom: 20px;
}

h2 {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 10px;
}

li {
  margin-bottom: 20px;
}

h3 {
  font-size: 20px;
  margin-bottom: 10px;
}

</style>