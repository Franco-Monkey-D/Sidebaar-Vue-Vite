import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import loremIpsum from 'lorem-ipsum';


const router = createRouter({
    history: createWebHistory(),
    routes:[
        {
            path:'/',
            component: Home
        },
        {
            path:'/about',
            component: ()=> import('../views/About.vue')
        },
        {
            path:'/config',
            component: ()=> import('../views/Config.vue')
        },
        {
            path:'/explore',
            component: ()=> import('../views/Explore.vue')
        },

    ]
})


export default router
